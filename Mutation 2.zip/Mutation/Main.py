from Check import *


# call function here
# display what user need to input
# displayText()
# check .....


# check start overlapping
StartOverlap("1438") # replace the text

# check end overlapping
EndOverlap("7293") # replace the text

in_Between_Parents("1374", "1401")# replace the text

parent_in_betaween_mutation('1366', '1401') # replace the text

start_end()


# in between parent
# Input 1.csv to 6.csv since CSV reader failed to read over 900 data per time
with open('1.csv') as csv_file:
        csv_reader = csv.reader(csv_file)
        open('CSV_In_Between_Parents.txt', 'w').close() # rewrite each time
        file1 = open("CSV_In_Between_Parents.txt","a") 
        line_count = 0
        text = ""        
        for row in csv_reader:
            text = str(row[0] +"," + row[1])
            CSV_In_Between_Parents(text)
            file1.write(CSV_In_Between_Parents(text))
            file1.write("\n")
            line_count += 1

# Input 1.csv to 6.csv since CSV reader failed to read over 900 data per time
with open('1.csv') as csv_file:
        csv_reader = csv.reader(csv_file)
        open('CSV_parent_in_betaween_mutation.txt', 'w').close() # rewrite each time
        file1 = open("CSV_parent_in_betaween_mutation.txt","a") 
        line_count = 0
        text = ""        
        for row in csv_reader:
            # print(row)
            text = str(row[0] +"," + row[1])
            CSV_parent_in_betaween_mutation(text)
            file1.write(str(CSV_parent_in_betaween_mutation(text)))
            file1.write("\n")
            line_count += 1